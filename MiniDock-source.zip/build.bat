@echo off
rem MinGW-w64 编译（需要 gcc / windres）
windres -O coff res/app.rc -o res/app_res.o -Ires
gcc -Os -mwindows -s -static-libgcc -o MiniDock.exe minidock.c res/app_res.o -lgdiplus -lole32 -loleaut32 -lshell32 -lshlwapi -luser32 -lgdi32 -lcomctl32 -lcomdlg32 -luuid -lurlmon -lversion -ldwmapi -ladvapi32
