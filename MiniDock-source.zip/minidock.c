/*  MiniDock - tiny macOS-style dock for Windows.  Made by Wangcy
 *  Pure Win32 + GDI+ (flat API).  Single portable exe, config stored next to the exe.
 */
#define UNICODE
#define _UNICODE
#define _WIN32_WINNT 0x0601
#define WINVER 0x0601
#define COBJMACROS
#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <commctrl.h>
#include <commoncontrols.h>
#include <commdlg.h>
#include <urlmon.h>
#include <oleidl.h>
#include <dwmapi.h>
#include <math.h>
#include <wchar.h>

/* ------------------------------------------------------------------ */
/* Minimal GDI+ flat API declarations (headers shipped with MinGW are C++ only) */
/* ------------------------------------------------------------------ */
typedef int GpStatus;
typedef float REAL;
typedef DWORD ARGB;
typedef void GpGraphics, GpImage, GpBitmap, GpBrush, GpPath, GpPen, GpFont, GpFontFamily, GpStringFormat, GpImageAttributes;
typedef struct { UINT32 GdiplusVersion; void *DebugEventCallback; BOOL SuppressBackgroundThread; BOOL SuppressExternalCodecs; } GdiplusStartupInput;
typedef struct { REAL X, Y, Width, Height; } RectF;
#define GPAPI WINAPI
#define PXF_PARGB 0xE200B
GpStatus GPAPI GdiplusStartup(ULONG_PTR *, const GdiplusStartupInput *, void *);
void GPAPI GdiplusShutdown(ULONG_PTR);
GpStatus GPAPI GdipCreateBitmapFromScan0(INT, INT, INT, INT, BYTE *, GpBitmap **);
GpStatus GPAPI GdipCreateBitmapFromHICON(HICON, GpBitmap **);
GpStatus GPAPI GdipCreateBitmapFromFile(const WCHAR *, GpBitmap **);
GpStatus GPAPI GdipGetImageWidth(GpImage *, UINT *);
GpStatus GPAPI GdipGetImageHeight(GpImage *, UINT *);
GpStatus GPAPI GdipDisposeImage(GpImage *);
GpStatus GPAPI GdipGetImageGraphicsContext(GpImage *, GpGraphics **);
GpStatus GPAPI GdipDeleteGraphics(GpGraphics *);
GpStatus GPAPI GdipGraphicsClear(GpGraphics *, ARGB);
GpStatus GPAPI GdipSetSmoothingMode(GpGraphics *, INT);
GpStatus GPAPI GdipSetInterpolationMode(GpGraphics *, INT);
GpStatus GPAPI GdipSetPixelOffsetMode(GpGraphics *, INT);
GpStatus GPAPI GdipSetTextRenderingHint(GpGraphics *, INT);
GpStatus GPAPI GdipResetWorldTransform(GpGraphics *);
GpStatus GPAPI GdipTranslateWorldTransform(GpGraphics *, REAL, REAL, INT);
GpStatus GPAPI GdipCreateSolidFill(ARGB, GpBrush **);
GpStatus GPAPI GdipSetSolidFillColor(GpBrush *, ARGB);
GpStatus GPAPI GdipDeleteBrush(GpBrush *);
GpStatus GPAPI GdipCreateLineBrushFromRect(const RectF *, ARGB, ARGB, INT, INT, GpBrush **);
GpStatus GPAPI GdipCreatePen1(ARGB, REAL, INT, GpPen **);
GpStatus GPAPI GdipDeletePen(GpPen *);
GpStatus GPAPI GdipCreatePath(INT, GpPath **);
GpStatus GPAPI GdipDeletePath(GpPath *);
GpStatus GPAPI GdipAddPathArc(GpPath *, REAL, REAL, REAL, REAL, REAL, REAL);
GpStatus GPAPI GdipClosePathFigure(GpPath *);
GpStatus GPAPI GdipFillPath(GpGraphics *, GpBrush *, GpPath *);
GpStatus GPAPI GdipDrawPath(GpGraphics *, GpPen *, GpPath *);
GpStatus GPAPI GdipFillRectangle(GpGraphics *, GpBrush *, REAL, REAL, REAL, REAL);
GpStatus GPAPI GdipFillEllipse(GpGraphics *, GpBrush *, REAL, REAL, REAL, REAL);
GpStatus GPAPI GdipDrawLine(GpGraphics *, GpPen *, REAL, REAL, REAL, REAL);
GpStatus GPAPI GdipDrawImageRectRect(GpGraphics *, GpImage *, REAL, REAL, REAL, REAL, REAL, REAL, REAL, REAL, INT, const GpImageAttributes *, void *, void *);
GpStatus GPAPI GdipCreateImageAttributes(GpImageAttributes **);
GpStatus GPAPI GdipDisposeImageAttributes(GpImageAttributes *);
GpStatus GPAPI GdipSetImageAttributesWrapMode(GpImageAttributes *, INT, ARGB, BOOL);
GpStatus GPAPI GdipSetImageAttributesColorMatrix(GpImageAttributes *, INT, BOOL, const float *, const float *, INT);
GpStatus GPAPI GdipCreateFontFamilyFromName(const WCHAR *, void *, GpFontFamily **);
GpStatus GPAPI GdipGetGenericFontFamilySansSerif(GpFontFamily **);
GpStatus GPAPI GdipCreateFont(const GpFontFamily *, REAL, INT, INT, GpFont **);
GpStatus GPAPI GdipDeleteFont(GpFont *);
GpStatus GPAPI GdipCreateStringFormat(INT, LANGID, GpStringFormat **);
GpStatus GPAPI GdipDeleteStringFormat(GpStringFormat *);
GpStatus GPAPI GdipSetStringFormatAlign(GpStringFormat *, INT);
GpStatus GPAPI GdipSetStringFormatLineAlign(GpStringFormat *, INT);
GpStatus GPAPI GdipSetStringFormatTrimming(GpStringFormat *, INT);
GpStatus GPAPI GdipStringFormatGetGenericTypographic(GpStringFormat **);
GpStatus GPAPI GdipDrawString(GpGraphics *, const WCHAR *, INT, const GpFont *, const RectF *, const GpStringFormat *, const GpBrush *);
GpStatus GPAPI GdipMeasureString(GpGraphics *, const WCHAR *, INT, const GpFont *, const RectF *, const GpStringFormat *, RectF *, INT *, INT *);

static const GUID MY_IID_IImageList = {0x46EB5926,0x582E,0x4017,{0x9F,0xDF,0xE8,0x99,0x8D,0xAA,0x09,0x50}};
#define ARGBC(a, r, g, b) ((ARGB)(((DWORD)(a) << 24) | ((DWORD)(r) << 16) | ((DWORD)(g) << 8) | (DWORD)(b)))
#define PI_F 3.14159265f

/* ------------------------------------------------------------------ */
/* Types & globals                                                     */
/* ------------------------------------------------------------------ */
#define MAXI 96
#define WM_APP_ICON (WM_APP + 1)
#define WM_APP_TRAY (WM_APP + 2)
#define T_ANIM 1
#define T_SCAN 2
#define T_HIDE 3
#define T_SAVE 4
#define T_TRIM 5
#define CLS_DOCK L"MiniDockWnd"
#define CLS_SET L"MiniDockSettings"
#define CLS_IN L"MiniDockInput"

enum { T_FILE = 0, T_FOLDER = 1, T_URL = 2, T_SEP = 3 };

typedef struct {
    int type, appmode, fav;
    WCHAR name[128];
    WCHAR path[1024];
    WCHAR target[MAX_PATH];
    GpBitmap *icon;
    float cur, slide, prevL;
    BOOL running;
    DWORD bounce;
} Item;

typedef struct {
    int iconSize, zoomSize, spacing, margin, pad, radius, opacity;
    int zoom, dark, dots, labels, bounce, autohide, webApp;
} Cfg;

static Cfg cfg;
static Item items[MAXI];
static int nItems;
static HINSTANCE g_inst;
static HWND g_hwnd, g_hset;
static ULONG_PTR g_gdipTok;
static int g_dpi = 96;
static WCHAR g_ini[MAX_PATH], g_dir[MAX_PATH], g_iconDir[MAX_PATH], g_exe[MAX_PATH];
static UINT g_taskbarMsg;
static int g_cacheSize = 96;
static BOOL g_noDl;

/* rendering */
static HDC g_memdc;
static HBITMAP g_dib, g_oldbmp;
static BYTE *g_bits;
static GpBitmap *g_surf;
static GpGraphics *g_g;
static int winX, winY, winW, winH;
static RECT g_wa;
static GpImageAttributes *g_attr, *g_attrFade;
static GpFont *g_font, *g_fontBold;
static GpStringFormat *g_fmtC, *g_fmtL;

/* layout state (window coordinates) */
static float slotL[MAXI + 1], slotR[MAXI + 1], actC[MAXI + 1], baseC[MAXI + 1];
static int prevN = -1;
static float barL, barW, barTop, barBottom;
static float gHideCur;
static int gHideTgt;
static DWORD gLastNear;
static BOOL gMenuOpen, gAnimOn, gMoved, gFsHidden;
static int mouseX = -1, mouseY = -1, hot = -1;
static BOOL hover;
static int pressIdx = -1;
static POINT pressPt;
static BOOL dragging, removing;
static int dragIdx = -1;
static POINT dragPt;
static int gapIdx = -1;
static float gapCur;

typedef struct {
    float S, Z, g, padX, sepW, pad, barH, overhang, margin;
    int winW, winH;
} Metrics;
static Metrics M;

/* forward declarations */
static void Kick(void);
static BOOL RenderFrame(void);
static void ScheduleSave(void);
static void UpdateGeometry(void);
static void ApplySettings(void);
static void ShowSettings(void);
static void LaunchItem(int i);
static LRESULT CALLBACK DockProc(HWND, UINT, WPARAM, LPARAM);

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
static int Sc(int v) { return MulDiv(v, g_dpi, 96); }
static float Clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

static void DefaultCfg(void) {
    cfg.iconSize = Sc(48);
    cfg.zoomSize = Sc(80);
    cfg.spacing = Sc(6);
    cfg.margin = Sc(8);
    cfg.pad = Sc(8);
    cfg.radius = Sc(16);
    cfg.opacity = 72;
    cfg.zoom = 1;
    cfg.dark = 1;
    cfg.dots = 1;
    cfg.labels = 1;
    cfg.bounce = 1;
    cfg.autohide = 0;
    cfg.webApp = 1;
}

static void EnsureIni(void) {
    if (GetFileAttributesW(g_ini) != INVALID_FILE_ATTRIBUTES) return;
    HANDLE h = CreateFileW(g_ini, GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        WORD bom = 0xFEFF;
        DWORD w;
        WriteFile(h, &bom, 2, &w, NULL);
        CloseHandle(h);
    }
}

static void InitPaths(void) {
    GetModuleFileNameW(NULL, g_exe, MAX_PATH);
    lstrcpyW(g_dir, g_exe);
    PathRemoveFileSpecW(g_dir);
    PathCombineW(g_ini, g_dir, L"MiniDock.ini");
    EnsureIni();
    HANDLE h = CreateFileW(g_ini, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) { /* exe folder not writable -> use %APPDATA% */
        WCHAR ap[MAX_PATH];
        SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, ap);
        PathCombineW(g_dir, ap, L"MiniDock");
        CreateDirectoryW(g_dir, NULL);
        PathCombineW(g_ini, g_dir, L"MiniDock.ini");
        EnsureIni();
    } else CloseHandle(h);
    PathCombineW(g_iconDir, g_dir, L"icons");
    CreateDirectoryW(g_iconDir, NULL);
}

static BOOL IsUrlStr(const WCHAR *s) {
    return StrCmpNIW(s, L"http://", 7) == 0 || StrCmpNIW(s, L"https://", 8) == 0 || StrCmpNIW(s, L"www.", 4) == 0;
}

static void HostOf(const WCHAR *url, WCHAR *out, int cch) {
    const WCHAR *p = wcsstr(url, L"://");
    p = p ? p + 3 : url;
    int n = 0;
    while (*p && *p != L'/' && *p != L':' && *p != L'?' && *p != L'#' && n < cch - 1) out[n++] = *p++;
    out[n] = 0;
}

static DWORD Fnv(const WCHAR *s) {
    DWORD h = 2166136261u;
    for (; *s; s++) { h ^= (WORD)(*s | 0x20 * 0); h *= 16777619u; }
    return h;
}

static void IconFileFor(const WCHAR *url, WCHAR *out) {
    WCHAR host[256];
    HostOf(url, host, 256);
    CharLowerW(host);
    WCHAR nm[40];
    wsprintfW(nm, L"%08x.png", Fnv(host));
    PathCombineW(out, g_iconDir, nm);
}

static BOOL IsRunningTitleExe(const WCHAR *p) { return PathMatchSpecW(p, L"*.exe"); }

/* ------------------------------------------------------------------ */
/* Config                                                              */
/* ------------------------------------------------------------------ */
static int RdI(const WCHAR *k, int d) { return (int)GetPrivateProfileIntW(L"Settings", k, d, g_ini); }
static void WrI(const WCHAR *k, int v) {
    WCHAR b[24];
    wsprintfW(b, L"%d", v);
    WritePrivateProfileStringW(L"Settings", k, b, g_ini);
}

static int CacheFor(int z) {
    if (z <= 96) return 96;
    if (z <= 128) return 128;
    if (z <= 192) return 192;
    return 256;
}

static void ResolveTarget(Item *it) {
    it->target[0] = 0;
    if (it->type != T_FILE) return;
    if (PathMatchSpecW(it->path, L"*.lnk")) {
        IShellLinkW *psl = NULL;
        if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&psl))) {
            IPersistFile *ppf = NULL;
            if (SUCCEEDED(IShellLinkW_QueryInterface(psl, &IID_IPersistFile, (void **)&ppf))) {
                if (SUCCEEDED(IPersistFile_Load(ppf, it->path, STGM_READ))) {
                    WCHAR t[MAX_PATH] = L"";
                    IShellLinkW_GetPath(psl, t, MAX_PATH, NULL, 0);
                    if (IsRunningTitleExe(t)) lstrcpyW(it->target, t);
                }
                IPersistFile_Release(ppf);
            }
            IShellLinkW_Release(psl);
        }
    } else if (IsRunningTitleExe(it->path)) lstrcpynW(it->target, it->path, MAX_PATH);
}

/* ------------------------------------------------------------------ */
/* Icons                                                               */
/* ------------------------------------------------------------------ */
static void DrawRoundRectPath(GpPath *p, float x, float y, float w, float h, float r) {
    float d = r * 2;
    if (d > w) d = w;
    if (d > h) d = h;
    if (d < 0.5f) { d = 0.5f; }
    GdipAddPathArc(p, x, y, d, d, 180, 90);
    GdipAddPathArc(p, x + w - d, y, d, d, 270, 90);
    GdipAddPathArc(p, x + w - d, y + h - d, d, d, 0, 90);
    GdipAddPathArc(p, x, y + h - d, d, d, 90, 90);
    GdipClosePathFigure(p);
}

static void FillRoundRect(GpGraphics *g, GpBrush *b, float x, float y, float w, float h, float r) {
    GpPath *p;
    GdipCreatePath(0, &p);
    DrawRoundRectPath(p, x, y, w, h, r);
    GdipFillPath(g, b, p);
    GdipDeletePath(p);
}

static void DrawImg(GpGraphics *g, GpBitmap *src, float x, float y, float w, float h, BOOL fade) {
    UINT sw = 0, sh = 0;
    GdipGetImageWidth(src, &sw);
    GdipGetImageHeight(src, &sh);
    GdipDrawImageRectRect(g, src, x, y, w, h, 0, 0, (REAL)sw, (REAL)sh, 2, fade ? g_attrFade : g_attr, NULL, NULL);
}

static void SetupG(GpGraphics *g) {
    GdipSetSmoothingMode(g, 4);
    GdipSetInterpolationMode(g, 7);
    GdipSetPixelOffsetMode(g, 4);
    GdipSetTextRenderingHint(g, 4);
}

static GpBitmap *NewCache(int s, GpGraphics **gout) {
    GpBitmap *b = NULL;
    GdipCreateBitmapFromScan0(s, s, 0, PXF_PARGB, NULL, &b);
    if (b) { GdipGetImageGraphicsContext(b, gout); SetupG(*gout); }
    return b;
}

static void HsvRgb(float h, float s, float v, int *r, int *g, int *b) {
    float c = v * s, hp = h / 60.f, x = c * (1 - fabsf(fmodf(hp, 2) - 1)), r1 = 0, g1 = 0, b1 = 0;
    if (hp < 1) { r1 = c; g1 = x; } else if (hp < 2) { r1 = x; g1 = c; } else if (hp < 3) { g1 = c; b1 = x; }
    else if (hp < 4) { g1 = x; b1 = c; } else if (hp < 5) { r1 = x; b1 = c; } else { r1 = c; b1 = x; }
    float m = v - c;
    *r = (int)((r1 + m) * 255); *g = (int)((g1 + m) * 255); *b = (int)((b1 + m) * 255);
}

static void DrawCentered(GpGraphics *g, const WCHAR *t, GpFont *f, float x, float y, float w, float h, ARGB col) {
    GpBrush *br;
    GdipCreateSolidFill(col, &br);
    RectF rc = { x, y, w, h };
    GdipDrawString(g, t, -1, f, &rc, g_fmtC, br);
    GdipDeleteBrush(br);
}

static GpBitmap *LetterTile(const WCHAR *name, int cs) {
    GpGraphics *g = NULL;
    GpBitmap *b = NewCache(cs, &g);
    if (!b) return NULL;
    WCHAR host[256];
    lstrcpynW(host, name, 256);
    float hue = (float)(Fnv(host) % 360);
    int r1, g1, b1, r2, g2, b2;
    HsvRgb(hue, 0.55f, 0.95f, &r1, &g1, &b1);
    HsvRgb(hue, 0.75f, 0.70f, &r2, &g2, &b2);
    float m = cs * 0.06f;
    RectF rc = { m, m, cs - 2 * m, cs - 2 * m };
    GpBrush *br;
    GdipCreateLineBrushFromRect(&rc, ARGBC(255, r1, g1, b1), ARGBC(255, r2, g2, b2), 1, 0, &br);
    FillRoundRect(g, br, m, m, cs - 2 * m, cs - 2 * m, cs * 0.2f);
    GdipDeleteBrush(br);
    WCHAR ch[3] = { 0, 0, 0 };
    const WCHAR *p = name;
    if (StrCmpNIW(p, L"www.", 4) == 0) p += 4;
    ch[0] = *p ? *p : L'?';
    CharUpperBuffW(ch, 1);
    GpFontFamily *fam = NULL;
    GpFont *f = NULL;
    if (GdipCreateFontFamilyFromName(L"Microsoft YaHei UI", NULL, &fam) != 0) GdipGetGenericFontFamilySansSerif(&fam);
    GdipCreateFont(fam, cs * 0.5f, 1, 2, &f);
    DrawCentered(g, ch, f, 0, 0, (float)cs, (float)cs, ARGBC(255, 255, 255, 255));
    GdipDeleteFont(f);
    GdipDeleteGraphics(g);
    return b;
}

static GpBitmap *FaviconBitmap(const WCHAR *file, int cs) {
    GpBitmap *src = NULL;
    if (GdipCreateBitmapFromFile(file, &src) != 0 || !src) return NULL;
    UINT w = 0, h = 0;
    GdipGetImageWidth(src, &w);
    GdipGetImageHeight(src, &h);
    if (w < 8 || h < 8) { GdipDisposeImage(src); return NULL; }
    GpGraphics *g = NULL;
    GpBitmap *b = NewCache(cs, &g);
    if (!b) { GdipDisposeImage(src); return NULL; }
    if (w < 64) { /* small favicon -> put on a white rounded tile */
        float m = cs * 0.06f;
        RectF rc = { m, m, cs - 2 * m, cs - 2 * m };
        GpBrush *br;
        GdipCreateLineBrushFromRect(&rc, ARGBC(255, 255, 255, 255), ARGBC(255, 232, 234, 240), 1, 0, &br);
        FillRoundRect(g, br, m, m, cs - 2 * m, cs - 2 * m, cs * 0.2f);
        GdipDeleteBrush(br);
        float s = cs * 0.55f, o = (cs - s) / 2;
        DrawImg(g, src, o, o, s, s, FALSE);
    } else {
        float s = cs * 0.9f, o = (cs - s) / 2;
        DrawImg(g, src, o, o, s, s, FALSE);
    }
    GdipDeleteGraphics(g);
    GdipDisposeImage(src);
    return b;
}

static GpBitmap *ShellIconBitmap(const WCHAR *path, int cs) {
    SHFILEINFOW sfi;
    ZeroMemory(&sfi, sizeof sfi);
    if (!SHGetFileInfoW(path, 0, &sfi, sizeof sfi, SHGFI_SYSICONINDEX)) return NULL;
    HICON hi = NULL;
    static const int lists[2] = { SHIL_JUMBO, SHIL_EXTRALARGE };
    for (int k = 0; k < 2 && !hi; k++) {
        IImageList *il = NULL;
        if (SUCCEEDED(SHGetImageList(lists[k], &MY_IID_IImageList, (void **)&il)) && il) {
            IImageList_GetIcon(il, sfi.iIcon, ILD_TRANSPARENT, &hi);
            IImageList_Release(il);
        }
    }
    if (!hi) {
        ZeroMemory(&sfi, sizeof sfi);
        if (SHGetFileInfoW(path, 0, &sfi, sizeof sfi, SHGFI_ICON | SHGFI_LARGEICON)) hi = sfi.hIcon;
    }
    if (!hi) return NULL;
    GpBitmap *src = NULL;
    GdipCreateBitmapFromHICON(hi, &src);
    DestroyIcon(hi);
    if (!src) return NULL;
    GpGraphics *g = NULL;
    GpBitmap *b = NewCache(cs, &g);
    if (b) {
        DrawImg(g, src, 0, 0, (float)cs, (float)cs, FALSE);
        GdipDeleteGraphics(g);
    }
    GdipDisposeImage(src);
    return b;
}

typedef struct { WCHAR host[256]; WCHAR file[MAX_PATH]; } DlJob;

static DWORD WINAPI DlThread(LPVOID p) {
    DlJob *j = (DlJob *)p;
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
    static const WCHAR *fmts[3] = { L"https://www.google.com/s2/favicons?domain=%s&sz=128", L"https://%s/favicon.ico", L"https://icons.duckduckgo.com/ip3/%s.ico" };
    WCHAR u[700], tmp[MAX_PATH + 8];
    lstrcpyW(tmp, j->file);
    lstrcatW(tmp, L".tmp");
    for (int k = 0; k < 3; k++) {
        wsprintfW(u, fmts[k], j->host);
        DeleteFileW(tmp);
        if (URLDownloadToFileW(NULL, u, tmp, 0, NULL) == S_OK) {
            WIN32_FILE_ATTRIBUTE_DATA fa;
            if (GetFileAttributesExW(tmp, GetFileExInfoStandard, &fa) && fa.nFileSizeLow > 150) {
                MoveFileExW(tmp, j->file, MOVEFILE_REPLACE_EXISTING);
                break;
            }
        }
        DeleteFileW(tmp);
    }
    if (g_hwnd) PostMessageW(g_hwnd, WM_APP_ICON, 0, 0);
    CoUninitialize();
    HeapFree(GetProcessHeap(), 0, j);
    return 0;
}

static void StartFaviconDownload(const WCHAR *url, const WCHAR *file) {
    DlJob *j = (DlJob *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(DlJob));
    if (!j) return;
    HostOf(url, j->host, 256);
    lstrcpynW(j->file, file, MAX_PATH);
    HANDLE h = CreateThread(NULL, 0, DlThread, j, 0, NULL);
    if (h) CloseHandle(h); else HeapFree(GetProcessHeap(), 0, j);
}

static void LoadItemIcon(Item *it) {
    if (it->icon) { GdipDisposeImage(it->icon); it->icon = NULL; }
    it->fav = 0;
    if (it->type == T_SEP) return;
    int cs = g_cacheSize;
    if (it->type == T_URL) {
        WCHAR f[MAX_PATH], host[256];
        IconFileFor(it->path, f);
        if (GetFileAttributesW(f) != INVALID_FILE_ATTRIBUTES) {
            it->icon = FaviconBitmap(f, cs);
            if (it->icon) it->fav = 1; else DeleteFileW(f);
        } else if (!g_noDl) StartFaviconDownload(it->path, f);
        if (!it->icon) { HostOf(it->path, host, 256); it->icon = LetterTile(host, cs); }
    } else {
        it->icon = ShellIconBitmap(it->path, cs);
        if (!it->icon) it->icon = LetterTile(it->name, cs);
    }
}

static void ReloadAllIcons(void) {
    for (int i = 0; i < nItems; i++) LoadItemIcon(&items[i]);
}

/* ------------------------------------------------------------------ */
/* Item management                                                     */
/* ------------------------------------------------------------------ */
static void FileDescr(const WCHAR *path, WCHAR *out, int cch) {
    out[0] = 0;
    DWORD h;
    DWORD sz = GetFileVersionInfoSizeW(path, &h);
    if (!sz) return;
    void *buf = LocalAlloc(LMEM_FIXED, sz);
    if (!buf) return;
    if (GetFileVersionInfoW(path, 0, sz, buf)) {
        struct { WORD l, c; } *tr = NULL;
        UINT len = 0;
        if (VerQueryValueW(buf, L"\\VarFileInfo\\Translation", (LPVOID *)&tr, &len) && len >= 4) {
            WCHAR q[96], *v = NULL;
            wsprintfW(q, L"\\StringFileInfo\\%04x%04x\\FileDescription", tr[0].l, tr[0].c);
            if (VerQueryValueW(buf, q, (LPVOID *)&v, &len) && len > 1) lstrcpynW(out, v, cch);
            if (!out[0]) {
                wsprintfW(q, L"\\StringFileInfo\\%04x%04x\\ProductName", tr[0].l, tr[0].c);
                if (VerQueryValueW(buf, q, (LPVOID *)&v, &len) && len > 1) lstrcpynW(out, v, cch);
            }
        }
    }
    LocalFree(buf);
}

static void CleanName(WCHAR *n) {
    for (WCHAR *p = n; *p; p++) if (*p == L'|' || *p == L'\r' || *p == L'\n') *p = L'/';
}

static int InsertItem(int idx, int type, const WCHAR *name, const WCHAR *path, int appmode) {
    if (nItems >= MAXI) return -1;
    if (idx < 0 || idx > nItems) idx = nItems;
    memmove(&items[idx + 1], &items[idx], sizeof(Item) * (nItems - idx));
    nItems++;
    Item *it = &items[idx];
    ZeroMemory(it, sizeof(Item));
    it->type = type;
    it->appmode = appmode;
    if (name) lstrcpynW(it->name, name, 128);
    if (path) lstrcpynW(it->path, path, 1024);
    CleanName(it->name);
    it->cur = 0;
    ResolveTarget(it);
    LoadItemIcon(it);
    gMoved = TRUE;
    for (int i = 0; i < nItems; i++) items[i].prevL = (i < idx) ? slotL[i] : (i == idx ? slotL[i] : slotL[i - 1]);
    return idx;
}

static void RemoveItem(int i) {
    if (i < 0 || i >= nItems) return;
    if (items[i].icon) GdipDisposeImage(items[i].icon);
    memmove(&items[i], &items[i + 1], sizeof(Item) * (nItems - i - 1));
    nItems--;
    prevN = -1;
    ScheduleSave();
    Kick();
}

static void MoveItem(int from, int to) {
    if (from == to || from < 0 || to < 0 || from >= nItems || to >= nItems) return;
    for (int i = 0; i < nItems; i++) items[i].prevL = slotL[i];
    Item tmp = items[from];
    if (from < to) memmove(&items[from], &items[from + 1], sizeof(Item) * (to - from));
    else memmove(&items[to + 1], &items[to], sizeof(Item) * (from - to));
    items[to] = tmp;
    gMoved = TRUE;
}

/* Classify a dropped path / url and add it. Returns index of the inserted item or -1 */
static int AddFromString(const WCHAR *s0, int idx) {
    WCHAR s[1024], name[128];
    lstrcpynW(s, s0, 1024);
    StrTrimW(s, L" \t\r\n\"");
    if (!s[0]) return -1;
    if (IsUrlStr(s)) {
        WCHAR url[1024];
        if (StrCmpNIW(s, L"www.", 4) == 0) wsprintfW(url, L"https://%s", s); else lstrcpyW(url, s);
        HostOf(url, name, 128);
        WCHAR *nm = name;
        if (StrCmpNIW(nm, L"www.", 4) == 0) nm += 4;
        int r = InsertItem(idx, T_URL, nm, url, cfg.webApp);
        if (r >= 0) ScheduleSave();
        return r;
    }
    DWORD at = GetFileAttributesW(s);
    if (at == INVALID_FILE_ATTRIBUTES) return -1;
    if (at & FILE_ATTRIBUTE_DIRECTORY) {
        WCHAR *b = PathFindFileNameW(s);
        lstrcpynW(name, (b && *b) ? b : s, 128);
        int r = InsertItem(idx, T_FOLDER, name, s, 0);
        if (r >= 0) ScheduleSave();
        return r;
    }
    if (PathMatchSpecW(s, L"*.url")) { /* internet shortcut */
        WCHAR url[1024] = L"";
        GetPrivateProfileStringW(L"InternetShortcut", L"URL", L"", url, 1024, s);
        if (url[0]) {
            lstrcpynW(name, PathFindFileNameW(s), 128);
            PathRemoveExtensionW(name);
            int r = InsertItem(idx, T_URL, name, url, cfg.webApp);
            if (r >= 0) ScheduleSave();
            return r;
        }
    }
    lstrcpynW(name, PathFindFileNameW(s), 128);
    PathRemoveExtensionW(name);
    if (PathMatchSpecW(s, L"*.exe")) {
        WCHAR d[128];
        FileDescr(s, d, 128);
        if (d[0]) lstrcpynW(name, d, 128);
    }
    int r = InsertItem(idx, T_FILE, name, s, 0);
    if (r >= 0) ScheduleSave();
    return r;
}

static void LoadItems(void) {
    int cnt = (int)GetPrivateProfileIntW(L"Items", L"Count", 0, g_ini);
    for (int i = 0; i < cnt && i < MAXI; i++) {
        WCHAR k[16], v[2048];
        wsprintfW(k, L"I%d", i);
        GetPrivateProfileStringW(L"Items", k, L"", v, 2048, g_ini);
        WCHAR *p1 = wcschr(v, L'|');
        if (!p1) continue;
        WCHAR *p2 = wcschr(p1 + 1, L'|');
        if (!p2) continue;
        WCHAR *p3 = wcschr(p2 + 1, L'|');
        if (!p3) continue;
        *p1 = *p2 = *p3 = 0;
        int type = _wtoi(v), am = _wtoi(p1 + 1);
        if (type < 0 || type > 3) continue;
        int r = InsertItem(-1, type, p2 + 1, p3 + 1, am);
        if (r >= 0) items[r].cur = type == T_SEP ? 0 : 0;
    }
    gMoved = FALSE;
}

static void SaveNow(void) {
    EnsureIni();
    WrI(L"IconSize", cfg.iconSize); WrI(L"ZoomSize", cfg.zoomSize); WrI(L"Spacing", cfg.spacing);
    WrI(L"Margin", cfg.margin); WrI(L"Padding", cfg.pad); WrI(L"Radius", cfg.radius); WrI(L"Opacity", cfg.opacity);
    WrI(L"Zoom", cfg.zoom); WrI(L"Dark", cfg.dark); WrI(L"Dots", cfg.dots); WrI(L"Labels", cfg.labels);
    WrI(L"Bounce", cfg.bounce); WrI(L"AutoHide", cfg.autohide); WrI(L"WebAppMode", cfg.webApp);
    WritePrivateProfileStringW(L"Items", NULL, NULL, g_ini);
    WCHAR b[24];
    wsprintfW(b, L"%d", nItems);
    WritePrivateProfileStringW(L"Items", L"Count", b, g_ini);
    for (int i = 0; i < nItems; i++) {
        WCHAR k[16], v[2048];
        wsprintfW(k, L"I%d", i);
        wsprintfW(v, L"%d|%d|%s|%s", items[i].type, items[i].appmode, items[i].name, items[i].path);
        WritePrivateProfileStringW(L"Items", k, v, g_ini);
    }
}

static void LoadConfig(void) {
    DefaultCfg();
    cfg.iconSize = RdI(L"IconSize", cfg.iconSize); cfg.zoomSize = RdI(L"ZoomSize", cfg.zoomSize);
    cfg.spacing = RdI(L"Spacing", cfg.spacing); cfg.margin = RdI(L"Margin", cfg.margin);
    cfg.pad = RdI(L"Padding", cfg.pad); cfg.radius = RdI(L"Radius", cfg.radius); cfg.opacity = RdI(L"Opacity", cfg.opacity);
    cfg.zoom = RdI(L"Zoom", cfg.zoom); cfg.dark = RdI(L"Dark", cfg.dark); cfg.dots = RdI(L"Dots", cfg.dots);
    cfg.labels = RdI(L"Labels", cfg.labels); cfg.bounce = RdI(L"Bounce", cfg.bounce);
    cfg.autohide = RdI(L"AutoHide", cfg.autohide); cfg.webApp = RdI(L"WebAppMode", cfg.webApp);
    if (cfg.iconSize < 16) cfg.iconSize = 16;
    if (cfg.iconSize > 256) cfg.iconSize = 256;
}

static void ScheduleSave(void) { if (g_hwnd) SetTimer(g_hwnd, T_SAVE, 700, NULL); }

/* Autostart (HKCU Run) */
#define RUNKEY L"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
static BOOL GetAutostart(void) {
    HKEY k;
    BOOL r = FALSE;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, RUNKEY, 0, KEY_READ, &k) == ERROR_SUCCESS) {
        r = RegQueryValueExW(k, L"MiniDock", NULL, NULL, NULL, NULL) == ERROR_SUCCESS;
        RegCloseKey(k);
    }
    return r;
}
static void SetAutostart(BOOL on) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, RUNKEY, 0, NULL, 0, KEY_WRITE, NULL, &k, NULL) != ERROR_SUCCESS) return;
    if (on) {
        WCHAR v[MAX_PATH + 4];
        wsprintfW(v, L"\"%s\"", g_exe);
        RegSetValueExW(k, L"MiniDock", 0, REG_SZ, (BYTE *)v, (lstrlenW(v) + 1) * 2);
    } else RegDeleteValueW(k, L"MiniDock");
    RegCloseKey(k);
}

/* ------------------------------------------------------------------ */
/* Geometry / metrics                                                  */
/* ------------------------------------------------------------------ */
static void CalcMetrics(void) {
    float S0 = (float)cfg.iconSize, Z0 = (float)(cfg.zoom ? (cfg.zoomSize > cfg.iconSize ? cfg.zoomSize : cfg.iconSize) : cfg.iconSize);
    float g0 = (float)cfg.spacing, pad0 = (float)cfg.pad, sep0 = 10.f + g0 * 0.5f;
    float padX0 = pad0 + 2;
    int nIcon = 0, nSep = 0;
    for (int i = 0; i < nItems; i++) { if (items[i].type == T_SEP) nSep++; else nIcon++; }
    float wb = 2 * padX0 + nIcon * S0 + nSep * sep0 + (nItems > 1 ? g0 * (nItems - 1) : 0);
    if (nItems == 0) wb = 2 * padX0 + S0 * 3;
    float waW = (float)(g_wa.right - g_wa.left);
    float limit = waW - 40, fit = 1;
    if (wb > limit) fit = Clampf((limit - 2 * padX0) / (wb - 2 * padX0), 0.25f, 1.f);
    M.S = S0 * fit; M.Z = Z0 * fit; M.g = g0 * fit; M.sepW = sep0 * fit;
    M.pad = pad0; M.padX = padX0; M.margin = (float)cfg.margin;
    M.barH = M.S + 2 * M.pad + 4;
    float over = (M.Z - M.S - M.pad > 0 ? M.Z - M.S - M.pad : 0) + M.S * 0.55f + 34 + 8;
    M.overhang = over;
    float w = wb * fit + (M.Z - M.S) * 6 + M.S + 260;
    if (nItems == 0) w = wb + 260;
    if (w > waW) w = waW;
    M.winW = (int)w;
    M.winH = (int)(M.barH + over + M.margin) + 2;
}

static void FreeSurface(void) {
    if (g_g) { GdipDeleteGraphics(g_g); g_g = NULL; }
    if (g_surf) { GdipDisposeImage(g_surf); g_surf = NULL; }
    if (g_dib) { SelectObject(g_memdc, g_oldbmp); DeleteObject(g_dib); g_dib = NULL; }
    g_bits = NULL;
}

static void MakeSurface(int w, int h) {
    FreeSurface();
    BITMAPINFO bi;
    ZeroMemory(&bi, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    g_dib = CreateDIBSection(g_memdc, &bi, DIB_RGB_COLORS, (void **)&g_bits, NULL, 0);
    if (!g_dib) return;
    g_oldbmp = (HBITMAP)SelectObject(g_memdc, g_dib);
    GdipCreateBitmapFromScan0(w, h, w * 4, PXF_PARGB, g_bits, &g_surf);
    GdipGetImageGraphicsContext(g_surf, &g_g);
    SetupG(g_g);
}

static void UpdateGeometry(void) {
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &g_wa, 0);
    CalcMetrics();
    if (M.winW != winW || M.winH != winH || !g_dib) {
        winW = M.winW; winH = M.winH;
        MakeSurface(winW, winH);
    }
    winX = g_wa.left + ((g_wa.right - g_wa.left) - winW) / 2;
    winY = g_wa.bottom - winH;
}

/* ------------------------------------------------------------------ */
/* Running state                                                       */
/* ------------------------------------------------------------------ */
typedef struct { BOOL changed; BOOL seen[MAXI]; } ScanCtx;

static BOOL ExeOfWindow(HWND h, WCHAR *out) {
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (!pid) return FALSE;
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!p) return FALSE;
    DWORD n = MAX_PATH;
    BOOL ok = QueryFullProcessImageNameW(p, 0, out, &n);
    CloseHandle(p);
    return ok;
}

static BOOL IsAppWindow(HWND h) {
    if (!IsWindowVisible(h)) return FALSE;
    if (GetWindow(h, GW_OWNER)) return FALSE;
    if (GetWindowLongW(h, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) return FALSE;
    if (GetWindowTextLengthW(h) == 0) return FALSE;
    int cloaked = 0;
    DwmGetWindowAttribute(h, 14, &cloaked, sizeof cloaked);
    if (cloaked) return FALSE;
    return TRUE;
}

static BOOL CALLBACK ScanProc(HWND h, LPARAM lp) {
    ScanCtx *c = (ScanCtx *)lp;
    if (!IsAppWindow(h) || h == g_hwnd || h == g_hset) return TRUE;
    WCHAR exe[MAX_PATH];
    if (!ExeOfWindow(h, exe)) return TRUE;
    for (int i = 0; i < nItems; i++)
        if (items[i].target[0] && !c->seen[i] && lstrcmpiW(items[i].target, exe) == 0) c->seen[i] = TRUE;
    return TRUE;
}

static void ScanRunning(void) {
    ScanCtx c;
    ZeroMemory(&c, sizeof c);
    if (cfg.dots) EnumWindows(ScanProc, (LPARAM)&c);
    for (int i = 0; i < nItems; i++)
        if (items[i].running != c.seen[i]) { items[i].running = c.seen[i]; c.changed = TRUE; }
    if (c.changed) Kick();
}

typedef struct { const WCHAR *exe; BOOL close; BOOL done; } ActCtx;
static BOOL CALLBACK ActProc(HWND h, LPARAM lp) {
    ActCtx *c = (ActCtx *)lp;
    if (!IsAppWindow(h) || h == g_hwnd) return TRUE;
    WCHAR exe[MAX_PATH];
    if (!ExeOfWindow(h, exe) || lstrcmpiW(exe, c->exe) != 0) return TRUE;
    if (c->close) { PostMessageW(h, WM_CLOSE, 0, 0); return TRUE; }
    if (IsIconic(h)) ShowWindow(h, SW_RESTORE);
    SetForegroundWindow(h);
    c->done = TRUE;
    return FALSE;
}

static BOOL ActivateApp(const WCHAR *exe, BOOL close) {
    ActCtx c = { exe, close, FALSE };
    EnumWindows(ActProc, (LPARAM)&c);
    return c.done;
}

static BOOL IsFullscreenForeground(void) {
    HWND f = GetForegroundWindow();
    if (!f || f == g_hwnd || f == g_hset || f == GetDesktopWindow() || f == GetShellWindow()) return FALSE;
    WCHAR cls[64];
    GetClassNameW(f, cls, 64);
    if (!lstrcmpW(cls, L"Progman") || !lstrcmpW(cls, L"WorkerW") || !lstrcmpW(cls, L"Shell_TrayWnd")) return FALSE;
    RECT r;
    GetWindowRect(f, &r);
    HMONITOR m = MonitorFromWindow(f, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi = { sizeof mi };
    GetMonitorInfoW(m, &mi);
    if (!(r.left <= mi.rcMonitor.left && r.top <= mi.rcMonitor.top && r.right >= mi.rcMonitor.right && r.bottom >= mi.rcMonitor.bottom)) return FALSE;
    LONG st = GetWindowLongW(f, GWL_STYLE);
    return (st & WS_CAPTION) != WS_CAPTION;
}

/* ------------------------------------------------------------------ */
/* Launching                                                           */
/* ------------------------------------------------------------------ */
static void OpenUrlItem(Item *it) {
    WCHAR args[1100];
    if (it->appmode) {
        wsprintfW(args, L"--app=%s", it->path);
        if ((INT_PTR)ShellExecuteW(NULL, L"open", L"msedge.exe", args, NULL, SW_SHOWNORMAL) > 32) return;
        if ((INT_PTR)ShellExecuteW(NULL, L"open", L"chrome.exe", args, NULL, SW_SHOWNORMAL) > 32) return;
    }
    ShellExecuteW(NULL, L"open", it->path, NULL, NULL, SW_SHOWNORMAL);
}

static void LaunchItem(int i) {
    if (i < 0 || i >= nItems) return;
    Item *it = &items[i];
    if (it->type == T_SEP) return;
    if (it->type == T_FILE && it->target[0] && it->running && ActivateApp(it->target, FALSE)) return;
    if (cfg.bounce) { it->bounce = GetTickCount() | 1; }
    if (it->type == T_URL) OpenUrlItem(it);
    else {
        WCHAR dir[MAX_PATH];
        lstrcpynW(dir, it->path, MAX_PATH);
        if (it->type == T_FILE) PathRemoveFileSpecW(dir); else dir[0] = 0;
        ShellExecuteW(NULL, L"open", it->path, NULL, dir[0] ? dir : NULL, SW_SHOWNORMAL);
    }
    SetTimer(g_hwnd, T_SCAN, 1200, NULL);
    Kick();
}

/* ------------------------------------------------------------------ */
/* Rendering                                                           */
/* ------------------------------------------------------------------ */
static float MapActualToBase(float mx) {
    if (prevN != nItems || nItems == 0) return mx;
    if (nItems == 1) return baseC[0] + (mx - actC[0]);
    if (mx <= actC[0]) return baseC[0] + (mx - actC[0]);
    if (mx >= actC[nItems - 1]) return baseC[nItems - 1] + (mx - actC[nItems - 1]);
    for (int i = 0; i < nItems - 1; i++) {
        if (mx >= actC[i] && mx < actC[i + 1]) {
            float d = actC[i + 1] - actC[i];
            float t = d > 0.001f ? (mx - actC[i]) / d : 0;
            return baseC[i] + t * (baseC[i + 1] - baseC[i]);
        }
    }
    return mx;
}

static int HitIndex(float x, float y) {
    if (gHideCur > 0.5f) return -1;
    if (y < barTop - M.Z - 16 || y > barBottom + M.margin) return -1;
    for (int i = 0; i < nItems; i++)
        if (items[i].cur > 1 && x >= slotL[i] - M.g / 2 && x < slotR[i] + M.g / 2) return i;
    return -1;
}

static float BounceOff(Item *it, BOOL *active) {
    if (!it->bounce) return 0;
    DWORD t = GetTickCount() - it->bounce;
    if (t > 1100) { it->bounce = 0; return 0; }
    *active = TRUE;
    float x = t / 1100.f;
    return fabsf(sinf(x * PI_F * 2.f)) * (1.f - x * 0.55f) * M.S * 0.48f;
}

static void DrawBubble(GpGraphics *g, const WCHAR *text, float cx, float y) {
    RectF lay = { 0, 0, 400, 40 }, bb = { 0, 0, 0, 0 };
    INT cp = 0, ln = 0;
    GdipMeasureString(g, text, -1, g_font, &lay, g_fmtL, &bb, &cp, &ln);
    float w = bb.Width + 22, h = 28;
    float x = cx - w / 2;
    if (x < 4) x = 4;
    if (x + w > winW - 4) x = winW - 4 - w;
    GpBrush *br;
    GdipCreateSolidFill(ARGBC(225, 38, 38, 42), &br);
    FillRoundRect(g, br, x, y, w, h, 9);
    GdipDeleteBrush(br);
    GpPen *pen;
    GdipCreatePen1(ARGBC(50, 255, 255, 255), 1, 2, &pen);
    GpPath *p;
    GdipCreatePath(0, &p);
    DrawRoundRectPath(p, x + 0.5f, y + 0.5f, w - 1, h - 1, 9);
    GdipDrawPath(g, pen, p);
    GdipDeletePath(p);
    GdipDeletePen(pen);
    DrawCentered(g, text, g_font, x, y, w, h, ARGBC(255, 245, 245, 247));
}

static BOOL RenderFrame(void) {
    if (!g_hwnd || !g_g) return FALSE;
    CalcMetrics();
    if (M.winW != winW || M.winH != winH) { UpdateGeometry(); }
    int n = nItems;
    BOOL anim = FALSE;
    float S = M.S, Z = M.Z, g = M.g, sepW = M.sepW, padX = M.padX, pad = M.pad;

    /* hide animation */
    float ht = (float)gHideTgt;
    if (fabsf(ht - gHideCur) > 0.004f) { gHideCur += (ht - gHideCur) * 0.28f; anim = TRUE; } else gHideCur = ht;

    /* base layout (no zoom) */
    float baseW = 2 * padX;
    for (int i = 0; i < n; i++) baseW += (items[i].type == T_SEP ? sepW : S);
    if (n > 1) baseW += g * (n - 1);
    if (n == 0) baseW = 2 * padX + S * 3;
    float bl = (winW - baseW) / 2, x = bl + padX;
    for (int i = 0; i < n; i++) {
        float w = items[i].type == T_SEP ? sepW : S;
        baseC[i] = x + w / 2;
        x += w + g;
    }

    /* hot item + zoom targets */
    BOOL mag = cfg.zoom && hover && dragIdx < 0 && gapIdx < 0 && n > 0 && mouseX >= 0 && gHideCur < 0.5f;
    float u = mag ? MapActualToBase((float)mouseX) : 0;
    float R = (S + g) * 2.6f;
    hot = (hover && dragIdx < 0) ? HitIndex((float)mouseX, (float)mouseY) : -1;
    for (int i = 0; i < n; i++) {
        Item *it = &items[i];
        float tgt;
        if (it->type == T_SEP) tgt = sepW;
        else {
            float w = 0;
            if (mag) {
                float d = fabsf(baseC[i] - u);
                if (d < R) w = 0.5f * (1.f + cosf(PI_F * d / R));
            }
            tgt = S + (Z - S) * w;
        }
        if (i == dragIdx) tgt = removing ? 0.f : (it->type == T_SEP ? sepW : S);
        float d = tgt - it->cur;
        if (fabsf(d) > 0.3f) { it->cur += d * 0.38f; anim = TRUE; } else it->cur = tgt;
    }
    float gapTgt = gapIdx >= 0 ? S : 0;
    if (fabsf(gapTgt - gapCur) > 0.3f) { gapCur += (gapTgt - gapCur) * 0.4f; anim = TRUE; } else gapCur = gapTgt;
    float G = (gapCur > 0.5f) ? gapCur + (n > 0 ? g : 0) : 0;

    /* actual layout */
    float tot = 2 * padX + G;
    for (int i = 0; i < n; i++) tot += items[i].cur;
    if (n > 1) tot += g * (n - 1);
    if (n == 0) tot += S * 3 - G + G;
    barW = tot;
    if (barW > winW - 4) barW = (float)(winW - 4);
    barL = (winW - barW) / 2;
    x = barL + padX;
    for (int i = 0; i < n; i++) {
        if (gapIdx == i && G > 0) x += G;
        slotL[i] = x;
        slotR[i] = x + items[i].cur;
        actC[i] = (slotL[i] + slotR[i]) / 2;
        x += items[i].cur + g;
    }
    prevN = n;
    if (gMoved) {
        for (int i = 0; i < n; i++) items[i].slide += items[i].prevL - slotL[i];
        gMoved = FALSE;
    }
    for (int i = 0; i < n; i++) {
        if (fabsf(items[i].slide) > 0.5f) { items[i].slide *= 0.62f; anim = TRUE; } else items[i].slide = 0;
    }

    barBottom = (float)winH - M.margin - 2;
    barTop = barBottom - M.barH;
    float iconBottom = barBottom - pad - 2;
    float off = gHideCur * (M.barH + M.margin + 14);
    GpGraphics *G_ = g_g;

    GdipGraphicsClear(G_, 0);
    if (gHideCur < 0.995f) {
        GdipResetWorldTransform(G_);
        GdipTranslateWorldTransform(G_, 0, off, 0);

        /* mouse hit zone (alpha 1 => receives mouse, practically invisible) */
        if (gHideCur < 0.5f) {
            float zt = (hover || dragging) ? barTop - Z - 16 : barTop - 2;
            GpBrush *hb;
            GdipCreateSolidFill(0x03000000, &hb);
            GdipFillRectangle(G_, hb, barL - 2, zt, barW + 4, barBottom - zt + (M.margin < 4 ? M.margin : 4));
            GdipDeleteBrush(hb);
        }

        /* bar background */
        ARGB c1, c2, cb;
        int al = (int)(cfg.opacity * 2.55f);
        if (cfg.dark) { c1 = ARGBC(al, 74, 76, 84); c2 = ARGBC(al, 30, 31, 36); cb = ARGBC(90, 255, 255, 255); }
        else { c1 = ARGBC(al, 255, 255, 255); c2 = ARGBC(al, 226, 229, 238); cb = ARGBC(150, 255, 255, 255); }
        float rad = (float)cfg.radius;
        if (rad > M.barH / 2) rad = M.barH / 2;
        RectF br = { barL, barTop, barW, M.barH };
        GpBrush *bb;
        GdipCreateLineBrushFromRect(&br, c1, c2, 1, 0, &bb);
        FillRoundRect(G_, bb, barL, barTop, barW, M.barH, rad);
        GdipDeleteBrush(bb);
        GpPen *pen;
        GdipCreatePen1(cb, 1.2f, 2, &pen);
        GpPath *pp;
        GdipCreatePath(0, &pp);
        DrawRoundRectPath(pp, barL + 0.6f, barTop + 0.6f, barW - 1.2f, M.barH - 1.2f, rad);
        GdipDrawPath(G_, pen, pp);
        GdipDeletePath(pp);
        GdipDeletePen(pen);

        if (n == 0) {
            DrawCentered(G_, L"将应用 / 文件夹 / 网址拖到这里", g_font, barL, barTop, barW, M.barH,
                         cfg.dark ? ARGBC(190, 255, 255, 255) : ARGBC(190, 40, 40, 40));
        }

        /* separators */
        GpPen *sp;
        GdipCreatePen1(cfg.dark ? ARGBC(95, 255, 255, 255) : ARGBC(110, 60, 60, 70), 1.2f, 2, &sp);
        for (int i = 0; i < n; i++) {
            if (items[i].type != T_SEP || items[i].cur < 2) continue;
            float cx = actC[i] + items[i].slide;
            GdipDrawLine(G_, sp, cx, iconBottom - S * 0.88f, cx, iconBottom - S * 0.04f);
        }
        GdipDeletePen(sp);

        /* icons */
        GpBrush *dotb;
        GdipCreateSolidFill(cfg.dark ? ARGBC(225, 235, 235, 240) : ARGBC(210, 50, 50, 60), &dotb);
        BOOL bAct = FALSE;
        for (int i = 0; i < n; i++) {
            Item *it = &items[i];
            if (it->type == T_SEP || i == dragIdx || it->cur < 1 || !it->icon) continue;
            float bo = BounceOff(it, &bAct);
            float sz = it->cur;
            float lx = slotL[i] + it->slide;
            DrawImg(G_, it->icon, lx, iconBottom - sz - bo, sz, sz, FALSE);
            if (it->running && cfg.dots) {
                float r = S / 24.f;
                if (r < 1.6f) r = 1.6f;
                GdipFillEllipse(G_, dotb, lx + sz / 2 - r, barBottom - (pad + 2) * 0.5f - r, r * 2, r * 2);
            }
        }
        GdipDeleteBrush(dotb);
        if (bAct) anim = TRUE;

        /* label */
        if (hot >= 0 && cfg.labels && items[hot].type != T_SEP && hover && gapIdx < 0 && items[hot].cur > 1) {
            float top = iconBottom - items[hot].cur - 8 - 28;
            DrawBubble(G_, items[hot].name, actC[hot], top);
        }

        /* drag ghost */
        if (dragIdx >= 0 && dragIdx < n && items[dragIdx].type != T_SEP && items[dragIdx].icon) {
            float sz = S * 1.15f;
            DrawImg(G_, items[dragIdx].icon, dragPt.x - sz / 2, dragPt.y - sz * 0.6f - off, sz, sz, TRUE);
            if (removing) DrawBubble(G_, L"移除", (float)dragPt.x, dragPt.y - sz * 0.6f - 36 - off);
        } else if (dragIdx >= 0 && removing) {
            DrawBubble(G_, L"移除", (float)dragPt.x, dragPt.y - 40 - off);
        }
    }

    POINT pt = { winX, winY };
    SIZE sz = { winW, winH };
    POINT src = { 0, 0 };
    BLENDFUNCTION bf = { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
    UpdateLayeredWindow(g_hwnd, NULL, &pt, &sz, g_memdc, &src, 0, &bf, ULW_ALPHA);
    return anim;
}

static void Kick(void) {
    if (!g_hwnd) return;
    if (!gAnimOn) { gAnimOn = TRUE; SetTimer(g_hwnd, T_ANIM, 15, NULL); }
    KillTimer(g_hwnd, T_TRIM);
}

/* ------------------------------------------------------------------ */
/* Input box (modal, for URL / rename)                                 */
/* ------------------------------------------------------------------ */
typedef struct {
    HWND hw, e1, e2;
    const WCHAR *title, *l1, *l2;
    WCHAR *b1, *b2;
    int n1, n2, ok, done;
} InCtx;

static HFONT g_uiFont;
static void SetFontAll(HWND parent) {
    for (HWND c = GetWindow(parent, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) SendMessageW(c, WM_SETFONT, (WPARAM)g_uiFont, TRUE);
}

static LRESULT CALLBACK InProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    InCtx *c = (InCtx *)GetWindowLongPtrW(h, GWLP_USERDATA);
    switch (m) {
    case WM_CREATE: {
        c = (InCtx *)((CREATESTRUCTW *)l)->lpCreateParams;
        SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)c);
        c->hw = h;
        int y = Sc(14), W = Sc(400);
        CreateWindowW(L"STATIC", c->l1, WS_CHILD | WS_VISIBLE, Sc(14), y, W - Sc(28), Sc(20), h, NULL, g_inst, NULL);
        y += Sc(22);
        c->e1 = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", c->b1, WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL, Sc(14), y, W - Sc(28), Sc(26), h, (HMENU)1001, g_inst, NULL);
        y += Sc(34);
        if (c->l2) {
            CreateWindowW(L"STATIC", c->l2, WS_CHILD | WS_VISIBLE, Sc(14), y, W - Sc(28), Sc(20), h, NULL, g_inst, NULL);
            y += Sc(22);
            c->e2 = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", c->b2, WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL, Sc(14), y, W - Sc(28), Sc(26), h, (HMENU)1002, g_inst, NULL);
            y += Sc(34);
        }
        CreateWindowW(L"BUTTON", L"确定", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON, W - Sc(180), y, Sc(80), Sc(28), h, (HMENU)IDOK, g_inst, NULL);
        CreateWindowW(L"BUTTON", L"取消", WS_CHILD | WS_VISIBLE | WS_TABSTOP, W - Sc(94), y, Sc(80), Sc(28), h, (HMENU)IDCANCEL, g_inst, NULL);
        SetFontAll(h);
        SetFocus(c->e1);
        SendMessageW(c->e1, EM_SETSEL, 0, -1);
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(w) == IDOK) {
            GetWindowTextW(c->e1, c->b1, c->n1);
            if (c->e2) GetWindowTextW(c->e2, c->b2, c->n2);
            c->ok = 1; c->done = 1;
            DestroyWindow(h);
        } else if (LOWORD(w) == IDCANCEL) { c->done = 1; DestroyWindow(h); }
        return 0;
    case WM_CLOSE: c->done = 1; DestroyWindow(h); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

static BOOL InputBox(HWND parent, const WCHAR *title, const WCHAR *l1, WCHAR *b1, int n1, const WCHAR *l2, WCHAR *b2, int n2) {
    InCtx c;
    ZeroMemory(&c, sizeof c);
    c.title = title; c.l1 = l1; c.l2 = l2; c.b1 = b1; c.b2 = b2; c.n1 = n1; c.n2 = n2;
    int W = Sc(400), H = Sc(l2 ? 190 : 130);
    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    RECT r = { 0, 0, W, H };
    AdjustWindowRectEx(&r, WS_CAPTION | WS_SYSMENU, FALSE, WS_EX_TOPMOST);
    HWND h = CreateWindowExW(WS_EX_TOPMOST | WS_EX_DLGMODALFRAME, CLS_IN, title, WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                             (wa.left + wa.right - (r.right - r.left)) / 2, (wa.top + wa.bottom - (r.bottom - r.top)) / 2 - Sc(60),
                             r.right - r.left, r.bottom - r.top, parent, NULL, g_inst, &c);
    if (!h) return FALSE;
    if (parent) EnableWindow(parent, FALSE);
    SetForegroundWindow(h);
    MSG msg;
    while (!c.done && GetMessageW(&msg, NULL, 0, 0) > 0) {
        if (!IsDialogMessageW(h, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    if (parent) { EnableWindow(parent, TRUE); SetForegroundWindow(parent); }
    return c.ok;
}

/* ------------------------------------------------------------------ */
/* Add helpers (used by menu + settings)                               */
/* ------------------------------------------------------------------ */
enum {
    IDM_OPEN = 100, IDM_QUITAPP, IDM_SHOWFOLDER, IDM_WEBAPP, IDM_RENAME, IDM_REMOVE, IDM_ADDSEP_AFTER, IDM_SETTINGS, IDM_EXIT,
    IDM_AUTOSTART, IDM_AUTOHIDE, IDM_ZOOM, IDM_ADDURL, IDM_ADDFILE, IDM_ADDFOLDER, IDM_ADDSEP_END, IDM_DELSEP
};

static void DoAddUrl(HWND parent) {
    WCHAR url[1024] = L"https://", name[128] = L"";
    if (!InputBox(parent, L"添加网页应用", L"网址：", url, 1024, L"名称（可留空，默认使用域名）：", name, 128)) return;
    StrTrimW(url, L" \t");
    if (!url[0]) return;
    if (!IsUrlStr(url)) { WCHAR t[1024]; wsprintfW(t, L"https://%s", url); lstrcpyW(url, t); }
    int r = AddFromString(url, -1);
    if (r >= 0 && name[0]) { lstrcpynW(items[r].name, name, 128); CleanName(items[r].name); ScheduleSave(); }
    UpdateGeometry();
    Kick();
}

static void DoAddFile(HWND parent) {
    WCHAR f[MAX_PATH] = L"";
    OPENFILENAMEW o;
    ZeroMemory(&o, sizeof o);
    o.lStructSize = sizeof o;
    o.hwndOwner = parent;
    o.lpstrFilter = L"应用程序与快捷方式\0*.exe;*.lnk;*.url\0所有文件\0*.*\0";
    o.lpstrFile = f;
    o.nMaxFile = MAX_PATH;
    o.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NODEREFERENCELINKS;
    o.lpstrTitle = L"选择要固定到 Dock 的应用或文件";
    if (GetOpenFileNameW(&o)) { AddFromString(f, -1); UpdateGeometry(); Kick(); }
}

static void DoAddFolder(HWND parent) {
    BROWSEINFOW b;
    ZeroMemory(&b, sizeof b);
    b.hwndOwner = parent;
    b.lpszTitle = L"选择要固定到 Dock 的文件夹";
    b.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    LPITEMIDLIST pi = SHBrowseForFolderW(&b);
    if (pi) {
        WCHAR p[MAX_PATH];
        if (SHGetPathFromIDListW(pi, p)) { AddFromString(p, -1); UpdateGeometry(); Kick(); }
        CoTaskMemFree(pi);
    }
}

static void DoAddSep(int idx) {
    InsertItem(idx, T_SEP, L"", L"", 0);
    ScheduleSave();
    UpdateGeometry();
    Kick();
}

/* ------------------------------------------------------------------ */
/* Menus                                                               */
/* ------------------------------------------------------------------ */
static void AppendCommon(HMENU m) {
    AppendMenuW(m, MF_STRING, IDM_SETTINGS, L"Dock 设置…");
    AppendMenuW(m, MF_STRING | (cfg.zoom ? MF_CHECKED : 0), IDM_ZOOM, L"悬停放大");
    AppendMenuW(m, MF_STRING | (cfg.autohide ? MF_CHECKED : 0), IDM_AUTOHIDE, L"自动隐藏");
    AppendMenuW(m, MF_STRING | (GetAutostart() ? MF_CHECKED : 0), IDM_AUTOSTART, L"开机自启动");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m, MF_STRING, IDM_EXIT, L"退出 Dock");
}

static void AppendAdd(HMENU m) {
    AppendMenuW(m, MF_STRING, IDM_ADDURL, L"添加网页应用…");
    AppendMenuW(m, MF_STRING, IDM_ADDFILE, L"添加应用 / 文件…");
    AppendMenuW(m, MF_STRING, IDM_ADDFOLDER, L"添加文件夹…");
    AppendMenuW(m, MF_STRING, IDM_ADDSEP_END, L"在末尾添加分割线");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
}

static int g_menuItem = -1;

static void HandleCmd(int id) {
    int i = g_menuItem;
    switch (id) {
    case IDM_OPEN: LaunchItem(i); break;
    case IDM_QUITAPP:
        if (i >= 0 && items[i].target[0]) ActivateApp(items[i].target, TRUE);
        break;
    case IDM_SHOWFOLDER:
        if (i >= 0) {
            WCHAR a[1100];
            wsprintfW(a, L"/select,\"%s\"", items[i].path);
            ShellExecuteW(NULL, L"open", L"explorer.exe", a, NULL, SW_SHOWNORMAL);
        }
        break;
    case IDM_WEBAPP:
        if (i >= 0) { items[i].appmode = !items[i].appmode; ScheduleSave(); }
        break;
    case IDM_RENAME:
        if (i >= 0) {
            WCHAR nm[128];
            lstrcpynW(nm, items[i].name, 128);
            if (InputBox(g_hset, L"重命名", L"名称：", nm, 128, NULL, NULL, 0) && nm[0]) {
                lstrcpynW(items[i].name, nm, 128);
                CleanName(items[i].name);
                ScheduleSave();
                Kick();
            }
        }
        break;
    case IDM_REMOVE:
    case IDM_DELSEP: if (i >= 0) RemoveItem(i); UpdateGeometry(); break;
    case IDM_ADDSEP_AFTER: DoAddSep(i >= 0 ? i + 1 : -1); break;
    case IDM_ADDSEP_END: DoAddSep(-1); break;
    case IDM_ADDURL: DoAddUrl(g_hset); break;
    case IDM_ADDFILE: DoAddFile(g_hset); break;
    case IDM_ADDFOLDER: DoAddFolder(g_hset); break;
    case IDM_SETTINGS: ShowSettings(); break;
    case IDM_ZOOM: cfg.zoom = !cfg.zoom; ApplySettings(); break;
    case IDM_AUTOHIDE: cfg.autohide = !cfg.autohide; ApplySettings(); break;
    case IDM_AUTOSTART: SetAutostart(!GetAutostart()); break;
    case IDM_EXIT: DestroyWindow(g_hwnd); break;
    }
}

static void ShowMenuAt(int item) {
    HMENU m = CreatePopupMenu();
    g_menuItem = item;
    if (item >= 0 && items[item].type == T_SEP) {
        AppendMenuW(m, MF_STRING, IDM_DELSEP, L"删除分割线");
        AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    } else if (item >= 0) {
        Item *it = &items[item];
        AppendMenuW(m, MF_STRING, IDM_OPEN, (it->running) ? L"切换到此应用" : L"打开");
        if (it->running && it->target[0]) AppendMenuW(m, MF_STRING, IDM_QUITAPP, L"退出应用");
        if (it->type == T_URL) AppendMenuW(m, MF_STRING | (it->appmode ? MF_CHECKED : 0), IDM_WEBAPP, L"以应用窗口打开（Edge/Chrome）");
        else AppendMenuW(m, MF_STRING, IDM_SHOWFOLDER, L"在文件夹中显示");
        AppendMenuW(m, MF_STRING, IDM_RENAME, L"重命名…");
        AppendMenuW(m, MF_STRING, IDM_ADDSEP_AFTER, L"在右侧添加分割线");
        AppendMenuW(m, MF_STRING, IDM_REMOVE, L"从 Dock 移除");
        AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    } else AppendAdd(m);
    AppendCommon(m);
    POINT p;
    GetCursorPos(&p);
    gMenuOpen = TRUE;
    SetForegroundWindow(g_hwnd);
    int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_BOTTOMALIGN | TPM_CENTERALIGN, p.x, p.y, 0, g_hwnd, NULL);
    PostMessageW(g_hwnd, WM_NULL, 0, 0);
    gMenuOpen = FALSE;
    DestroyMenu(m);
    if (cmd) HandleCmd(cmd);
    g_menuItem = -1;
    gLastNear = GetTickCount();
}

static void ShowTrayMenu(void) {
    HMENU m = CreatePopupMenu();
    g_menuItem = -1;
    AppendAdd(m);
    AppendCommon(m);
    POINT p;
    GetCursorPos(&p);
    gMenuOpen = TRUE;
    SetForegroundWindow(g_hwnd);
    int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_BOTTOMALIGN | TPM_RIGHTALIGN, p.x, p.y, 0, g_hwnd, NULL);
    PostMessageW(g_hwnd, WM_NULL, 0, 0);
    gMenuOpen = FALSE;
    DestroyMenu(m);
    if (cmd) HandleCmd(cmd);
}

/* ------------------------------------------------------------------ */
/* OLE drop target (files, folders, shortcuts, URLs dragged from browser) */
/* ------------------------------------------------------------------ */
static UINT cfUrlW, cfUrlA;
static BOOL g_dropOK;

static BOOL HasFmt(IDataObject *d, UINT cf) {
    FORMATETC fe = { (CLIPFORMAT)cf, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
    return IDataObject_QueryGetData(d, &fe) == S_OK;
}

static BOOL AcceptData(IDataObject *d) {
    return HasFmt(d, CF_HDROP) || HasFmt(d, cfUrlW) || HasFmt(d, cfUrlA) || HasFmt(d, CF_UNICODETEXT);
}

static int GapFromPoint(int sx, int sy) {
    POINT p = { sx, sy };
    ScreenToClient(g_hwnd, &p);
    float G = (gapCur > 0.5f) ? gapCur + M.g : 0;
    int idx = 0;
    for (int i = 0; i < nItems; i++) {
        float c = actC[i];
        if (G > 0) c += (gapIdx >= 0 && i >= gapIdx) ? -G / 2 : G / 2;
        if (c < p.x) idx = i + 1;
    }
    return idx;
}

static HRESULT STDMETHODCALLTYPE DT_QI(IDropTarget *t, REFIID riid, void **ppv) {
    if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDropTarget)) { *ppv = t; return S_OK; }
    *ppv = NULL;
    return E_NOINTERFACE;
}
static ULONG STDMETHODCALLTYPE DT_AddRef(IDropTarget *t) { return 2; }
static ULONG STDMETHODCALLTYPE DT_Release(IDropTarget *t) { return 1; }
static HRESULT STDMETHODCALLTYPE DT_Enter(IDropTarget *t, IDataObject *d, DWORD k, POINTL pt, DWORD *eff) {
    g_dropOK = AcceptData(d);
    if (g_dropOK) {
        gapIdx = GapFromPoint(pt.x, pt.y);
        *eff = DROPEFFECT_LINK;
        Kick();
    } else *eff = DROPEFFECT_NONE;
    return S_OK;
}
static HRESULT STDMETHODCALLTYPE DT_Over(IDropTarget *t, DWORD k, POINTL pt, DWORD *eff) {
    if (g_dropOK) {
        int ni = GapFromPoint(pt.x, pt.y);
        if (ni != gapIdx) { gapIdx = ni; Kick(); }
        *eff = DROPEFFECT_LINK;
    } else *eff = DROPEFFECT_NONE;
    return S_OK;
}
static HRESULT STDMETHODCALLTYPE DT_Leave(IDropTarget *t) { gapIdx = -1; Kick(); return S_OK; }

static BOOL GetGlobalText(IDataObject *d, UINT cf, BOOL wide, WCHAR *out, int cch) {
    FORMATETC fe = { (CLIPFORMAT)cf, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
    STGMEDIUM sm;
    if (IDataObject_GetData(d, &fe, &sm) != S_OK) return FALSE;
    BOOL ok = FALSE;
    void *p = GlobalLock(sm.hGlobal);
    if (p) {
        if (wide) lstrcpynW(out, (WCHAR *)p, cch);
        else MultiByteToWideChar(CP_ACP, 0, (char *)p, -1, out, cch);
        GlobalUnlock(sm.hGlobal);
        ok = out[0] != 0;
    }
    ReleaseStgMedium(&sm);
    return ok;
}

static HRESULT STDMETHODCALLTYPE DT_Drop(IDropTarget *t, IDataObject *d, DWORD k, POINTL pt, DWORD *eff) {
    int idx = gapIdx >= 0 ? gapIdx : nItems;
    float startCur = gapCur;
    int first = idx;
    BOOL any = FALSE;
    FORMATETC fe = { CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
    STGMEDIUM sm;
    if (IDataObject_GetData(d, &fe, &sm) == S_OK) {
        HDROP hd = (HDROP)GlobalLock(sm.hGlobal);
        if (hd) {
            UINT cnt = DragQueryFileW(hd, 0xFFFFFFFF, NULL, 0);
            for (UINT i = 0; i < cnt; i++) {
                WCHAR f[1024];
                DragQueryFileW(hd, i, f, 1024);
                int r = AddFromString(f, idx);
                if (r >= 0) { idx = r + 1; any = TRUE; }
            }
            GlobalUnlock(sm.hGlobal);
        }
        ReleaseStgMedium(&sm);
    } else {
        WCHAR s[1024];
        if (GetGlobalText(d, cfUrlW, TRUE, s, 1024) || GetGlobalText(d, cfUrlA, FALSE, s, 1024) || GetGlobalText(d, CF_UNICODETEXT, TRUE, s, 1024)) {
            WCHAR *nl = wcspbrk(s, L"\r\n");
            if (nl) *nl = 0;
            int r = AddFromString(s, idx);
            if (r >= 0) { idx = r + 1; any = TRUE; }
        }
    }
    gapIdx = -1;
    gapCur = 0;
    if (any) {
        for (int i = first; i < idx && i < nItems; i++) items[i].cur = startCur / (idx - first);
        *eff = DROPEFFECT_LINK;
        UpdateGeometry();
    } else *eff = DROPEFFECT_NONE;
    Kick();
    return S_OK;
}

static IDropTargetVtbl g_dtVtbl = { DT_QI, DT_AddRef, DT_Release, DT_Enter, DT_Over, DT_Leave, DT_Drop };
static IDropTarget g_dt = { &g_dtVtbl };

/* ------------------------------------------------------------------ */
/* Settings window                                                     */
/* ------------------------------------------------------------------ */
typedef struct { const WCHAR *label; int *val; int mn, mx; } SliderDef;
typedef struct { const WCHAR *label; int *val; } CheckDef;

static SliderDef g_sl[7];
static CheckDef g_ck[7];
#define ID_SL 300
#define ID_VAL 330
#define ID_CK 360
#define ID_B_URL 400
#define ID_B_FILE 401
#define ID_B_FOLDER 402
#define ID_B_SEP 403
#define ID_B_RESET 404
#define ID_B_CLOSE 405
#define ID_CK_AUTOSTART 380

static void InitDefs(void) {
    SliderDef s[7] = {
        { L"图标大小", &cfg.iconSize, 24, 128 }, { L"放大后大小", &cfg.zoomSize, 32, 220 }, { L"图标间距", &cfg.spacing, 0, 30 },
        { L"距离底部边距", &cfg.margin, 0, 150 }, { L"栏内边距（栏高）", &cfg.pad, 2, 30 }, { L"栏圆角", &cfg.radius, 0, 40 },
        { L"栏不透明度 %", &cfg.opacity, 10, 100 } };
    CheckDef c[7] = {
        { L"悬停放大", &cfg.zoom }, { L"显示名称标签", &cfg.labels }, { L"运行指示点", &cfg.dots }, { L"启动弹跳动画", &cfg.bounce },
        { L"深色主题", &cfg.dark }, { L"自动隐藏", &cfg.autohide }, { L"网页以应用窗口打开", &cfg.webApp } };
    memcpy(g_sl, s, sizeof s);
    memcpy(g_ck, c, sizeof c);
}

static void ApplySettings(void) {
    if (cfg.zoomSize < cfg.iconSize) cfg.zoomSize = cfg.iconSize;
    int need = CacheFor(cfg.zoom ? cfg.zoomSize : cfg.iconSize);
    if (need > g_cacheSize) { g_cacheSize = need; ReloadAllIcons(); }
    if (!cfg.autohide) { gHideTgt = 0; KillTimer(g_hwnd, T_HIDE); }
    else { SetTimer(g_hwnd, T_HIDE, 100, NULL); gLastNear = GetTickCount(); }
    UpdateGeometry();
    Kick();
    ScheduleSave();
}

static void SetValLabel(HWND h, int i) {
    WCHAR b[24];
    wsprintfW(b, L"%d", *g_sl[i].val);
    SetDlgItemTextW(h, ID_VAL + i, b);
}

static LRESULT CALLBACK SetProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: {
        int y = Sc(16), lx = Sc(18);
        for (int i = 0; i < 7; i++) {
            CreateWindowW(L"STATIC", g_sl[i].label, WS_CHILD | WS_VISIBLE, lx, y + Sc(4), Sc(130), Sc(22), h, NULL, g_inst, NULL);
            HWND tb = CreateWindowW(TRACKBAR_CLASSW, L"", WS_CHILD | WS_VISIBLE | TBS_HORZ | TBS_NOTICKS, lx + Sc(132), y, Sc(190), Sc(28), h, (HMENU)(INT_PTR)(ID_SL + i), g_inst, NULL);
            SendMessageW(tb, TBM_SETRANGE, TRUE, MAKELPARAM(g_sl[i].mn, g_sl[i].mx));
            SendMessageW(tb, TBM_SETPOS, TRUE, *g_sl[i].val);
            CreateWindowW(L"STATIC", L"", WS_CHILD | WS_VISIBLE | SS_RIGHT, lx + Sc(326), y + Sc(4), Sc(44), Sc(22), h, (HMENU)(INT_PTR)(ID_VAL + i), g_inst, NULL);
            SetValLabel(h, i);
            y += Sc(34);
        }
        y += Sc(8);
        int cw = Sc(180);
        for (int i = 0; i < 7; i++) {
            HWND c = CreateWindowW(L"BUTTON", g_ck[i].label, WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX | WS_TABSTOP,
                                   lx + (i % 2) * (cw + Sc(10)), y + (i / 2) * Sc(28), cw, Sc(24), h, (HMENU)(INT_PTR)(ID_CK + i), g_inst, NULL);
            SendMessageW(c, BM_SETCHECK, *g_ck[i].val ? BST_CHECKED : BST_UNCHECKED, 0);
        }
        HWND c = CreateWindowW(L"BUTTON", L"开机自启动", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX | WS_TABSTOP,
                               lx + Sc(190), y + 3 * Sc(28), cw, Sc(24), h, (HMENU)(INT_PTR)ID_CK_AUTOSTART, g_inst, NULL);
        SendMessageW(c, BM_SETCHECK, GetAutostart() ? BST_CHECKED : BST_UNCHECKED, 0);
        y += 4 * Sc(28) + Sc(10);
        int bw = Sc(118), bh = Sc(30), gx = Sc(8);
        const WCHAR *bt[6] = { L"添加网页应用…", L"添加应用 / 文件…", L"添加文件夹…", L"添加分割线", L"恢复默认设置", L"关闭" };
        int bid[6] = { ID_B_URL, ID_B_FILE, ID_B_FOLDER, ID_B_SEP, ID_B_RESET, ID_B_CLOSE };
        for (int i = 0; i < 6; i++)
            CreateWindowW(L"BUTTON", bt[i], WS_CHILD | WS_VISIBLE | WS_TABSTOP, lx + (i % 3) * (bw + gx), y + (i / 3) * (bh + gx), bw, bh, h, (HMENU)(INT_PTR)bid[i], g_inst, NULL);
        SetFontAll(h);
        return 0;
    }
    case WM_HSCROLL: {
        HWND tb = (HWND)l;
        int id = GetDlgCtrlID(tb) - ID_SL;
        if (id >= 0 && id < 7) {
            *g_sl[id].val = (int)SendMessageW(tb, TBM_GETPOS, 0, 0);
            SetValLabel(h, id);
            ApplySettings();
        }
        return 0;
    }
    case WM_COMMAND: {
        int id = LOWORD(w);
        if (id >= ID_CK && id < ID_CK + 7) {
            *g_ck[id - ID_CK].val = (SendMessageW((HWND)l, BM_GETCHECK, 0, 0) == BST_CHECKED);
            ApplySettings();
        } else if (id == ID_CK_AUTOSTART) SetAutostart(SendMessageW((HWND)l, BM_GETCHECK, 0, 0) == BST_CHECKED);
        else if (id == ID_B_URL) DoAddUrl(h);
        else if (id == ID_B_FILE) DoAddFile(h);
        else if (id == ID_B_FOLDER) DoAddFolder(h);
        else if (id == ID_B_SEP) DoAddSep(-1);
        else if (id == ID_B_RESET) {
            DefaultCfg();
            ApplySettings();
            DestroyWindow(h);
            ShowSettings();
        } else if (id == ID_B_CLOSE) DestroyWindow(h);
        return 0;
    }
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY:
        g_hset = NULL;
        SaveNow();
        return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

static void ShowSettings(void) {
    if (g_hset) { ShowWindow(g_hset, SW_SHOWNORMAL); SetForegroundWindow(g_hset); return; }
    InitDefs();
    int W = Sc(420), H = Sc(16 + 7 * 34 + 8 + 4 * 28 + 10 + 2 * 38 + 20);
    RECT r = { 0, 0, W, H };
    AdjustWindowRect(&r, WS_CAPTION | WS_SYSMENU, FALSE);
    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    g_hset = CreateWindowExW(WS_EX_TOPMOST, CLS_SET, L"MiniDock 设置", WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                             (wa.left + wa.right - (r.right - r.left)) / 2, (wa.top + wa.bottom - (r.bottom - r.top)) / 3,
                             r.right - r.left, r.bottom - r.top, NULL, NULL, g_inst, NULL);
    if (g_hset) SetForegroundWindow(g_hset);
}

/* ------------------------------------------------------------------ */
/* Tray                                                                */
/* ------------------------------------------------------------------ */
static NOTIFYICONDATAW g_nid;
static void AddTray(void) {
    ZeroMemory(&g_nid, sizeof g_nid);
    g_nid.cbSize = sizeof g_nid;
    g_nid.hWnd = g_hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_APP_TRAY;
    g_nid.hIcon = LoadIconW(g_inst, MAKEINTRESOURCEW(1));
    lstrcpyW(g_nid.szTip, L"MiniDock");
    Shell_NotifyIconW(NIM_ADD, &g_nid);
}

/* ------------------------------------------------------------------ */
/* Dock window                                                         */
/* ------------------------------------------------------------------ */
static void EndDrag(BOOL commit) {
    int di = dragIdx;
    BOOL rem = removing;
    dragging = FALSE;
    removing = FALSE;
    dragIdx = -1;
    if (commit && di >= 0 && rem) { RemoveItem(di); UpdateGeometry(); }
    else if (commit && di >= 0) ScheduleSave();
    Kick();
}

static void OnAutoHide(void) {
    if (!cfg.autohide) return;
    POINT p;
    GetCursorPos(&p);
    int scrH = GetSystemMetrics(SM_CYSCREEN);
    BOOL near_;
    if (gHideTgt) near_ = (p.x >= winX && p.x < winX + winW && p.y >= scrH - 2);
    else {
        float top = (float)winY + barTop - (cfg.zoom ? M.Z : M.S) - 10;
        near_ = (p.x >= winX && p.x < winX + winW && p.y >= top);
    }
    DWORD now = GetTickCount();
    if (near_ || gMenuOpen || dragging || gapIdx >= 0 || g_hset) {
        gLastNear = now;
        if (gHideTgt) { gHideTgt = 0; Kick(); }
    } else if (!gHideTgt && now - gLastNear > 450) { gHideTgt = 1; hover = FALSE; Kick(); }
}

static LRESULT CALLBACK DockProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: { PAINTSTRUCT ps; BeginPaint(h, &ps); EndPaint(h, &ps); return 0; }
    case WM_MOUSEMOVE: {
        int x = GET_X_LPARAM(l), y = GET_Y_LPARAM(l);
        mouseX = x; mouseY = y;
        if (!hover) {
            hover = TRUE;
            TRACKMOUSEEVENT te = { sizeof te, TME_LEAVE, h, 0 };
            TrackMouseEvent(&te);
        }
        if (GetCapture() == h && pressIdx >= 0) {
            if (!dragging && (abs(x - pressPt.x) > 6 || abs(y - pressPt.y) > 6)) { dragging = TRUE; dragIdx = pressIdx; }
            if (dragging) {
                dragPt.x = x; dragPt.y = y;
                removing = (y < barTop - M.S * 1.1f);
                if (!removing) {
                    int ni = 0;
                    for (int i = 0; i < nItems; i++) if (i != dragIdx && actC[i] < x) ni++;
                    if (ni != dragIdx) { MoveItem(dragIdx, ni); dragIdx = ni; pressIdx = ni; RenderFrame(); }
                }
            }
        }
        Kick();
        return 0;
    }
    case WM_MOUSELEAVE:
        if (!dragging) { hover = FALSE; mouseX = -1; hot = -1; Kick(); }
        return 0;
    case WM_LBUTTONDOWN:
        pressIdx = HitIndex((float)GET_X_LPARAM(l), (float)GET_Y_LPARAM(l));
        pressPt.x = GET_X_LPARAM(l); pressPt.y = GET_Y_LPARAM(l);
        if (pressIdx >= 0) SetCapture(h);
        return 0;
    case WM_LBUTTONUP: {
        BOOL was = dragging;
        int pi = pressIdx;
        pressIdx = -1;
        if (GetCapture() == h) ReleaseCapture();
        if (was) {
            EndDrag(TRUE);
            POINT cp;
            GetCursorPos(&cp);
            ScreenToClient(h, &cp);
            if (cp.x < barL || cp.x > barL + barW || cp.y < barTop - M.Z - 16 || cp.y > barBottom + M.margin) { hover = FALSE; mouseX = -1; hot = -1; Kick(); }
        }
        else if (pi >= 0) {
            int hi = HitIndex((float)GET_X_LPARAM(l), (float)GET_Y_LPARAM(l));
            if (hi == pi) LaunchItem(pi);
        }
        return 0;
    }
    case WM_CAPTURECHANGED:
        if (dragging) EndDrag(FALSE);
        return 0;
    case WM_RBUTTONUP: {
        int hi = HitIndex((float)GET_X_LPARAM(l), (float)GET_Y_LPARAM(l));
        ShowMenuAt(hi);
        return 0;
    }
    case WM_TIMER:
        if (w == T_ANIM) {
            if (!RenderFrame()) {
                KillTimer(h, T_ANIM);
                gAnimOn = FALSE;
                SetTimer(h, T_TRIM, 2500, NULL);
            }
        } else if (w == T_SCAN) {
            KillTimer(h, T_SCAN);
            SetTimer(h, T_SCAN, 2500, NULL);
            ScanRunning();
            BOOL fs = IsFullscreenForeground();
            if (fs && !gFsHidden) { gFsHidden = TRUE; ShowWindow(h, SW_HIDE); }
            else if (!fs && gFsHidden) { gFsHidden = FALSE; ShowWindow(h, SW_SHOWNA); Kick(); }
            if (!fs) SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        } else if (w == T_HIDE) OnAutoHide();
        else if (w == T_SAVE) { KillTimer(h, T_SAVE); SaveNow(); }
        else if (w == T_TRIM) { KillTimer(h, T_TRIM); SetProcessWorkingSetSize(GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1); }
        return 0;
    case WM_DISPLAYCHANGE:
    case WM_SETTINGCHANGE:
        UpdateGeometry();
        Kick();
        return 0;
    case WM_APP_ICON:
        g_noDl = TRUE;
        for (int i = 0; i < nItems; i++)
            if (items[i].type == T_URL && !items[i].fav) LoadItemIcon(&items[i]);
        g_noDl = FALSE;
        Kick();
        return 0;
    case WM_APP_TRAY:
        if (LOWORD(l) == WM_RBUTTONUP || LOWORD(l) == WM_CONTEXTMENU) ShowTrayMenu();
        else if (LOWORD(l) == WM_LBUTTONDBLCLK) ShowSettings();
        return 0;
    case WM_DESTROY:
        SaveNow();
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        RevokeDragDrop(h);
        PostQuitMessage(0);
        return 0;
    }
    if (m == g_taskbarMsg && m) { AddTray(); return 0; }
    return DefWindowProcW(h, m, w, l);
}

/* ------------------------------------------------------------------ */
/* Entry                                                               */
/* ------------------------------------------------------------------ */
int WINAPI WinMain(HINSTANCE hi, HINSTANCE hp, LPSTR cmd, int show) {
    g_inst = hi;
    HANDLE mtx = CreateMutexW(NULL, TRUE, L"Local\\MiniDock_Wangcy_Singleton");
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        HWND ex = FindWindowW(CLS_DOCK, NULL);
        if (ex) PostMessageW(ex, WM_APP_TRAY, 0, WM_LBUTTONDBLCLK);
        return 0;
    }
    HDC sdc = GetDC(NULL);
    g_dpi = GetDeviceCaps(sdc, LOGPIXELSX);
    ReleaseDC(NULL, sdc);
    OleInitialize(NULL);
    INITCOMMONCONTROLSEX ic = { sizeof ic, ICC_BAR_CLASSES };
    InitCommonControlsEx(&ic);
    GdiplusStartupInput gi = { 1, NULL, FALSE, FALSE };
    GdiplusStartup(&g_gdipTok, &gi, NULL);

    InitPaths();
    LoadConfig();
    g_cacheSize = CacheFor(cfg.zoom ? cfg.zoomSize : cfg.iconSize);

    /* shared GDI+ resources */
    GdipCreateImageAttributes(&g_attr);
    GdipSetImageAttributesWrapMode(g_attr, 3, 0, FALSE);
    GdipCreateImageAttributes(&g_attrFade);
    GdipSetImageAttributesWrapMode(g_attrFade, 3, 0, FALSE);
    {
        float cm[25] = { 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0.78f, 0, 0, 0, 0, 0, 1 };
        GdipSetImageAttributesColorMatrix(g_attrFade, 1, TRUE, cm, NULL, 0);
    }
    GpFontFamily *fam = NULL;
    if (GdipCreateFontFamilyFromName(L"Microsoft YaHei UI", NULL, &fam) != 0) GdipGetGenericFontFamilySansSerif(&fam);
    GdipCreateFont(fam, (REAL)Sc(13), 0, 2, &g_font);
    GdipCreateStringFormat(0, 0, &g_fmtC);
    GdipSetStringFormatAlign(g_fmtC, 1);
    GdipSetStringFormatLineAlign(g_fmtC, 1);
    GdipSetStringFormatTrimming(g_fmtC, 3);
    GdipCreateStringFormat(0x1000, 0, &g_fmtL);

    NONCLIENTMETRICSW ncm = { sizeof ncm };
    SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof ncm, &ncm, 0);
    g_uiFont = CreateFontIndirectW(&ncm.lfMessageFont);

    cfUrlW = RegisterClipboardFormatW(L"UniformResourceLocatorW");
    cfUrlA = RegisterClipboardFormatW(L"UniformResourceLocator");
    g_taskbarMsg = RegisterWindowMessageW(L"TaskbarCreated");

    WNDCLASSW wc;
    ZeroMemory(&wc, sizeof wc);
    wc.hInstance = hi;
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.lpfnWndProc = DockProc;
    wc.lpszClassName = CLS_DOCK;
    wc.hIcon = LoadIconW(hi, MAKEINTRESOURCEW(1));
    RegisterClassW(&wc);
    wc.lpfnWndProc = SetProc;
    wc.lpszClassName = CLS_SET;
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    RegisterClassW(&wc);
    wc.lpfnWndProc = InProc;
    wc.lpszClassName = CLS_IN;
    RegisterClassW(&wc);

    HDC dc = GetDC(NULL);
    g_memdc = CreateCompatibleDC(dc);
    ReleaseDC(NULL, dc);

    SystemParametersInfoW(SPI_GETWORKAREA, 0, &g_wa, 0);
    LoadItems();
    for (int i = 0; i < nItems; i++) items[i].cur = 0;
    UpdateGeometry();

    g_hwnd = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, CLS_DOCK, L"MiniDock", WS_POPUP,
                             winX, winY, winW, winH, NULL, NULL, hi, NULL);
    RegisterDragDrop(g_hwnd, &g_dt);
    AddTray();
    if (GetAutostart()) SetAutostart(TRUE); /* keep path fresh if the exe was moved */
    ShowWindow(g_hwnd, SW_SHOWNA);
    RenderFrame();
    Kick();
    SetTimer(g_hwnd, T_SCAN, 1500, NULL);
    if (cfg.autohide) { SetTimer(g_hwnd, T_HIDE, 100, NULL); gLastNear = GetTickCount(); }

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    for (int i = 0; i < nItems; i++) if (items[i].icon) GdipDisposeImage(items[i].icon);
    FreeSurface();
    GdiplusShutdown(g_gdipTok);
    OleUninitialize();
    if (mtx) CloseHandle(mtx);
    return 0;
}
